export type Place = {
  name: string;
  location: string;
  rating: number;
  openHour: string;
  price: string;
  description: string;
  lat: number;
  lng: number;
  category: "Restaurant" | "Cafe" | "Mall" | "Attractions" | "Beach";
};

export const dummyPlaces: Place[] = [
  {
    name: "Sampang Waterfall",
    location: "Sampang, Madura",
    rating: 4.7,
    openHour: "08.00 AM - 05.00 PM",
    price: "Rp 10.000",
    description: "Air terjun alami yang indah di Sampang.",
    lat: -7.0602,
    lng: 113.2829,
    category: "Attractions",
  },
  {
    name: "Cafe Madura",
    location: "Pamekasan, Madura",
    rating: 4.3,
    openHour: "10.00 AM - 11.00 PM",
    price: "Rp 20.000 - Rp 75.000",
    description: "Kafe dengan menu khas Madura.",
    lat: -7.1543,
    lng: 113.4796,
    category: "Cafe",
  },
  {
    name: "Bangkalan Mall",
    location: "Bangkalan, Madura",
    rating: 4.0,
    openHour: "09.00 AM - 09.00 PM",
    price: "Gratis",
    description: "Pusat perbelanjaan terbesar di Bangkalan.",
    lat: -7.0419,
    lng: 112.7448,
    category: "Mall",
  },
  {
    name: "Karapan Sapi Museum",
    location: "Sumenep, Madura",
    rating: 4.5,
    openHour: "08.00 AM - 04.00 PM",
    price: "Rp 15.000",
    description: "Museum budaya karapan sapi.",
    lat: -7.0085,
    lng: 113.8616,
    category: "Attractions",
  },
  {
    name: "Pantai Lombang",
    location: "Sumenep, Madura",
    rating: 4.8,
    openHour: "06.00 AM - 06.00 PM",
    price: "Rp 10.000",
    description: "Pantai dengan cemara udang.",
    lat: -6.9820,
    lng: 113.9853,
    category: "Beach",
  },
  {
    name: "Resto Bebek Sinjay",
    location: "Bangkalan, Madura",
    rating: 4.9,
    openHour: "09.00 AM - 09.00 PM",
    price: "Rp 30.000 - Rp 60.000",
    description: "Restoran bebek goreng legendaris.",
    lat: -7.0402,
    lng: 112.7413,
    category: "Restaurant",
  },
  {
    name: "Tebing Biru",
    location: "Bangkalan, Madura",
    rating: 4.4,
    openHour: "08.00 AM - 05.00 PM",
    price: "Rp 5.000",
    description: "Tebing dengan panorama laut biru.",
    lat: -6.9703,
    lng: 112.6876,
    category: "Attractions",
  },
  {
    name: "Sate Lalat Pak Seger",
    location: "Pamekasan, Madura",
    rating: 4.2,
    openHour: "10.00 AM - 10.00 PM",
    price: "Rp 25.000 - Rp 40.000",
    description: "Sate kecil khas Madura.",
    lat: -7.1600,
    lng: 113.4650,
    category: "Restaurant",
  },
  {
    name: "Alun-Alun Sumenep",
    location: "Sumenep, Madura",
    rating: 4.1,
    openHour: "24 Jam",
    price: "Gratis",
    description: "Ruang publik dan pusat kegiatan warga.",
    lat: -7.0041,
    lng: 113.8626,
    category: "Attractions",
  },
  {
    name: "Tanean Lanjhang",
    location: "Madura Timur",
    rating: 4.6,
    openHour: "24 Jam",
    price: "Gratis",
    description: "Kompleks rumah adat Madura.",
    lat: -7.1000,
    lng: 113.8000,
    category: "Attractions",
  },
];
