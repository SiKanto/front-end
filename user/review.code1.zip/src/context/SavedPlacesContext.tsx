import { createContext, useState, useContext, ReactNode } from "react";
import type { Place } from "../data/dummyPlaces";

interface SavedContextType {
  savedPlaces: Place[];
  toggleSave: (place: Place) => void;
}

const SavedContext = createContext<SavedContextType | undefined>(undefined);

export function SavedProvider({ children }: { children: ReactNode }) {
  const [savedPlaces, setSavedPlaces] = useState<Place[]>([]);

  const toggleSave = (place: Place) => {
    setSavedPlaces(prev => {
      const isAlreadySaved = prev.some(p => p.name === place.name);
      return isAlreadySaved
        ? prev.filter(p => p.name !== place.name)
        : [...prev, place];
    });
  };

  return (
    <SavedContext.Provider value={{ savedPlaces, toggleSave }}>
      {children}
    </SavedContext.Provider>
  );
}

export function useSavedPlaces() {
  const context = useContext(SavedContext);
  if (!context) throw new Error("useSavedPlaces must be used within SavedProvider");
  return context;
}
