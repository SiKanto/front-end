import { useContext } from "react";
import { SavedPlacesContext } from "../context/SavedPlacesContext";
import PlaceCard from "../components/PlaceCard";

export default function Saved() {
  const { savedPlaces } = useContext(SavedPlacesContext);

  return (
    <section className="saved-section">
      <h2>Saved Places</h2>
      {savedPlaces.length === 0 ? (
        <p>No places saved yet.</p>
      ) : (
        <div className="recommendation-grid">
          {savedPlaces.map((place) => (
            <PlaceCard key={place.id} {...place} />
          ))}
        </div>
      )}
    </section>
  );
}
