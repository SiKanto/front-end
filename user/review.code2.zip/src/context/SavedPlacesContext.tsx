import { createContext, useContext, useState, type ReactNode } from "react";
import type { Place } from "../data/dummyPlaces";

interface SavedContextType {
  savedPlaces: Place[];
  addPlace: (place: Place) => void;
  removePlace: (placeId: string) => void;
}

const SavedPlacesContext = createContext<SavedContextType | undefined>(undefined);

export const SavedPlacesProvider = ({ children }: { children: ReactNode }) => {
  const [savedPlaces, setSavedPlaces] = useState<Place[]>([]);

  const addPlace = (place: Place) => {
    setSavedPlaces((prev) => {
      if (!prev.find((p) => p.name === place.name)) {
        return [...prev, place];
      }
      return prev;
    });
  };

  const removePlace = (placeId: string) => {
    setSavedPlaces((prev) => prev.filter((p) => p.name !== placeId));
  };

  return (
    <SavedPlacesContext.Provider value={{ savedPlaces, addPlace, removePlace }}>
      {children}
    </SavedPlacesContext.Provider>
  );
};

export const useSavedPlaces = () => {
  const context = useContext(SavedPlacesContext);
  if (!context) {
    throw new Error("useSavedPlaces must be used within SavedPlacesProvider");
  }
  return context;
};
