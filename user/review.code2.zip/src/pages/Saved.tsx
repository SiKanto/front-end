import { useSavedPlaces } from "../context/SavedPlacesContext";

export default function Saved() {
  const { savedPlaces } = useSavedPlaces();

  return (
    <div style={{ padding: "24px" }}>
      <h2>Saved Places</h2>
      {savedPlaces.length === 0 ? (
        <p>No places saved yet.</p>
      ) : (
        <ul>
          {savedPlaces.map((place, i) => (
            <li key={i}>
              <strong>{place.name}</strong> - {place.location}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
