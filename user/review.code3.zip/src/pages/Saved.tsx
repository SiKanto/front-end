// file: src/pages/Saved.tsx

import { useSavedPlaces } from "../contexts/SavedPlacesContext";

export default function Saved() {
  const { savedPlaces } = useSavedPlaces();

  return (
    <section className="saved-page">
      <h2>Saved Places</h2>
      {savedPlaces.length === 0 ? (
        <p>You haven’t saved any places yet.</p>
      ) : (
        <ul>
          {savedPlaces.map((place) => (
            <li key={place.id}>
              <h3>{place.name}</h3>
              <p>{place.location}</p>
              <p>Rating: {place.rating}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
