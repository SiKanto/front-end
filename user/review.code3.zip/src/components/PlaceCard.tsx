// File: src/components/PlaceCard.tsx
import { Icon } from "@iconify/react";
import starIcon from "@iconify/icons-solar/star-bold";
import pinIcon from "@iconify/icons-solar/map-point-bold";
import "../styles/place-card.css";

export default function PlaceCard({ name, location, rating }: any) {
  return (
    <div className="place-card">
      <div className="place-image" />
      
      <div className="place-body">
        <div className="place-info">
          <p className="place-name">{name}</p>
          <div className="place-location">
            <Icon icon={pinIcon} className="icon" />
            {location}
          </div>
        </div>

        <div className="place-rating">
          <Icon icon={starIcon} className="icon" />
          {rating}
        </div>
      </div>
    </div>
  );
}
