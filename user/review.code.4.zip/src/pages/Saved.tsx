// src/pages/Saved.tsx
import { useSavedPlaces } from "../contexts/SavedPlacesContext";
import PlaceCard from "../components/PlaceCard";
import Navbar from "../components/Navbar"; // Pastikan file Header ada
import "../styles/saved-page.css";

export default function Saved() {
  const { savedPlaces } = useSavedPlaces();

  return (
    <>
      <Navbar isLoggedIn={true} onLogout={() => { /* TODO: implement logout */ }} /> {/* Ini akan menampilkan navigasi */}
      <section className="saved-page">
        <h2 className="saved-title">Saved Places</h2>
        {savedPlaces.length === 0 ? (
          <p className="no-saved">You haven’t saved any places yet.</p>
        ) : (
          <div className="saved-grid">
            {savedPlaces.map((place) => (
              <PlaceCard key={place.id} {...place} />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
